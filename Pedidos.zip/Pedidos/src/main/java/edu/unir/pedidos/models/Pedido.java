/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.unir.pedidos.models;

import java.util.Objects;

/**
 *
 * @author jhonj
 */
public class Pedido {
    private int idPedido;
    private String fecha;
    private String cantidad;
    private Distribuidor distribuidor;
    private Farmacia farmacia;
    private String medicamento;
    private String tipo;

    public Pedido() {
    }

    public Pedido(int idPedido, String fecha, String cantidad, Distribuidor distribuidor, Farmacia farmacia, String medicamento, String tipo) {
        this.idPedido = idPedido;
        this.fecha = fecha;
        this.cantidad = cantidad;
        this.distribuidor = distribuidor;
        this.farmacia = farmacia;
        this.medicamento = medicamento;
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Pedido{" + "idPedido=" + idPedido + ", fecha=" + fecha + ", cantidad=" + cantidad + ", distribuidor=" + distribuidor + ", farmacia=" + farmacia + ", medicamento=" + medicamento + '}';
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    

    public int getIdPedido() {
        return idPedido;
    }

    public String getFecha() {
        return fecha;
    }

    public String getCantidad() {
        return cantidad;
    }

    public Distribuidor getDistribuidor() {
        return distribuidor;
    }

    public Farmacia getFarmacia() {
        return farmacia;
    }

    public String getMedicamento() {
        return medicamento;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public void setDistribuidor(Distribuidor distribuidor) {
        this.distribuidor = distribuidor;
    }

    public void setFarmacia(Farmacia farmacia) {
        this.farmacia = farmacia;
    }

    public void setMedicamento(String medicamento) {
        this.medicamento = medicamento;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 47 * hash + this.idPedido;
        hash = 47 * hash + Objects.hashCode(this.fecha);
        hash = 47 * hash + Objects.hashCode(this.cantidad);
        hash = 47 * hash + Objects.hashCode(this.distribuidor);
        hash = 47 * hash + Objects.hashCode(this.farmacia);
        hash = 47 * hash + Objects.hashCode(this.medicamento);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Pedido other = (Pedido) obj;
        if (this.idPedido != other.idPedido) {
            return false;
        }
        if (!Objects.equals(this.fecha, other.fecha)) {
            return false;
        }
        if (!Objects.equals(this.cantidad, other.cantidad)) {
            return false;
        }
        if (!Objects.equals(this.distribuidor, other.distribuidor)) {
            return false;
        }
        if (!Objects.equals(this.farmacia, other.farmacia)) {
            return false;
        }
        if (!Objects.equals(this.medicamento, other.medicamento)) {
            return false;
        }
        return true;
    }
    
}
