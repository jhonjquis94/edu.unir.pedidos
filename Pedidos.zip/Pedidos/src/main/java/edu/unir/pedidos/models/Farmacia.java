/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.unir.pedidos.models;

import java.util.Objects;

/**
 *
 * @author jhonj
 */
public class Farmacia extends Empresa{
    
    private Sucursal sucursal;

    public Farmacia() {
    }
    
    public Farmacia (Sucursal sucursal) {
        super();
        this.sucursal = sucursal;
    }

    @Override
    public String toString() {
        
        return getNombre() + " " + getNit() +" " + getCiudad() + " " + getDireccion() + " " + getTelefono();
    }

   

    public Sucursal getSucursal() {
        return sucursal;
    }

    public void setSucursal(Sucursal sucursal) {
        this.sucursal = sucursal;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + Objects.hashCode(this.sucursal);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Farmacia other = (Farmacia) obj;
        if (!Objects.equals(this.sucursal, other.sucursal)) {
            return false;
        }
        return true;
    }
    
    
    public void crearFarmacia(String tipoSucursal){
        //Creamos sucursal 
        Sucursal s = new Sucursal("S001","Farmatodo Usaquen","Autopista Norte # 50-67", "Bogotá D.C",tipoSucursal);
        
        //Creamos empresa de tipo Farmacia
        Farmacia f = new Farmacia();
        f.setNombre("Farmatodo");
        f.setCiudad("Bogotá D.C");
        f.setNit("100587451-8");
        f.setDireccion("Carrera 67j # 83a-03");
        f.setTelefono("3258974568");
        f.setSucursal(s);
    
    }
    
    
    
}
