/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.unir.pedidos.models;

import java.util.Objects;



/**
 *
 * @author jhonj
 */
public class Empresa {
    private String nombre;
    private String nit;
    private String direccion;
    private String telefono;
    private String ciudad;
    private Sucursal sucursal;

    public Empresa() {
    }

    public Empresa(String nombre, String nit, String direccion, String telefono, String ciudad, Sucursal sucursal) {
        this.nombre = nombre;
        this.nit = nit;
        this.direccion = direccion;
        this.telefono = telefono;
        this.ciudad = ciudad;
        this.sucursal = sucursal;
    }
    
    
    
    // Se crean los setter para poder acceder a los a los atributos de empresa.
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public void setNit(String nit) {
        this.nit = nit;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public void setSucursal(Sucursal sucursal) {
        this.sucursal = sucursal;
    }
    
    
    // Se crean los getter para poder acceder a los a los atributos de empresa.
    public String getNombre() {
        return nombre;
    }

    public String getNit() {
        return nit;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCiudad() {
        return ciudad;
    }

    public Sucursal getSucursal() {
        return sucursal;
    }

    
    
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + Objects.hashCode(this.nombre);
        hash = 29 * hash + Objects.hashCode(this.nit);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Empresa other = (Empresa) obj;
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.nit, other.nit)) {
            return false;
        }
        return true;
    }
            
}
