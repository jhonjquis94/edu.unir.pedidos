/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.unir.pedidos.models;

/**
 *
 * @author jhonj
 */
public class Distribuidor extends Empresa{
    
    private String tipo;

    public Distribuidor() {
    }
    
    public Distribuidor(String tipo) {
        super();
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return getNombre() + " " + getNit() +" " + getCiudad() + " " + getDireccion() + " " + getTelefono();
    }
    
    
    public void crearDistribuidor(String nombreDistribuidor){
        
        //Creamos empresa de tipo Farmacia
        setNombre(nombreDistribuidor);
        setCiudad("Medellin");
        setNit("89631545200-8");
        setDireccion("calle 80 # 100-45");
        setTelefono("3136984567");
        
    }    
        
}
